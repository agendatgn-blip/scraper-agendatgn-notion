# AgendaTGN · Scraper de seguiment web

Sistema que revisa **cada 2 dies** el cercador oficial de l'Agenda de l'Ajuntament de Tarragona (https://agenda.tarragona.cat), busca tots els actes **des d'avui fins a 30 dies vista**, i crea entrades a la base **📥 INBOX AGENDA** de Notion amb estat *Pendent revisar*. No publica res automàticament i no inventa cap dada: el que no es veu clar entra com a "pendent de revisar".

Antiduplicats: cada acte de la web té un **UID únic** a la seva URL. Abans de crear res, el sistema consulta Notion i descarta els UIDs que ja hi són. Com a segona xarxa, si un títol+data coincideix amb una entrada existent, es crea igualment però marcada com a *"Possible duplicat — pendent de revisar"* (mai no s'esborra res).

---

## Instal·lació pas a pas (compte nou de GitHub)

### Pas 1 · Crear el repositori
1. Entra a github.com amb el teu compte.
2. Botó verd **New** (o github.com/new).
3. Nom: `agendatgn-scraper`. Marca **Private**. Botó **Create repository**.

### Pas 2 · Pujar aquests fitxers
1. Al repositori acabat de crear, clica l'enllaç **uploading an existing file**.
2. Arrossega-hi TOT el contingut d'aquesta carpeta (README.md, requirements.txt, la carpeta `scraper/`).
3. Botó verd **Commit changes**.
4. IMPORTANT — la carpeta `.github` sovint no es puja arrossegant perquè és oculta. Fes-ho a mà:
   - Al repositori: **Add file → Create new file**.
   - Al camp del nom escriu exactament: `.github/workflows/scraper.yml` (les barres creen les carpetes).
   - Enganxa-hi el contingut del fitxer `.github/workflows/scraper.yml` d'aquest paquet.
   - **Commit changes**.

### Pas 3 · Crear el token de Notion
1. Ves a https://www.notion.so/profile/integrations → **New integration**.
2. Nom: `AgendaTGN Scraper`. Workspace: el teu. Tipus: Internal.
3. Copia el **Internal Integration Secret** (comença per `ntn_` o `secret_`).
4. Dona-li accés a les dues bases (imprescindible!):
   - Obre **📥 INBOX AGENDA** a Notion → menú `···` (dalt a la dreta) → **Connexions / Connections** → afegeix `AgendaTGN Scraper`.
   - Repeteix-ho amb **🌐 FONTS WEB · Seguiment**.

### Pas 4 · Crear la clau de Gemini
1. Ves a https://aistudio.google.com → **Get API key** → **Create API key**.
2. Copia la clau (comença per `AIza`).

### Pas 5 · Guardar les claus al repositori (Secrets)
1. Al repositori de GitHub: **Settings → Secrets and variables → Actions**.
2. Botó **New repository secret** dues vegades:
   - Name: `NOTION_TOKEN` · Secret: el token del Pas 3.
   - Name: `GEMINI_API_KEY` · Secret: la clau del Pas 4.

### Pas 6 · Primera execució (mode test)
1. Pestanya **Actions** del repositori → si demana permís, botó **I understand... enable them**.
2. Al menú de l'esquerra: **AgendaTGN · Seguiment webs** → botó **Run workflow**.
3. Al camp *Mode test* escriu `si` → **Run workflow**.
4. Quan acabi (1-2 min), clica el run → job **scraper** → desplega "Executar el scraper" i mira el log: ha de dir quin format de data ha funcionat i llistar els actes trobats, **sense escriure res a Notion**.

### Pas 7 · Primera execució real
1. Torna a **Run workflow**, aquest cop amb *Mode test* = `no`.
2. Quan acabi, obre 📥 INBOX AGENDA a Notion: hi hauria d'haver les entrades noves, totes *Pendent revisar*, i la fitxa de la font a 🌐 FONTS WEB amb la data i el resum del run.
3. A partir d'aquí, el cron ho farà sol cada 2 dies. No cal tocar res més.

---

## Fitxers

| Fitxer | Què fa |
|---|---|
| `scraper/main.py` | Orquestra: cerca (avui → +30 dies), dedup per UID, crida Gemini, escriu a Notion |
| `scraper/notion_io.py` | Lectura/escriptura segura a Notion (INBOX i FONTS WEB) |
| `scraper/gemini_extract.py` | Extracció amb Gemini 2.5 Flash amb la regla "no inventar" |
| `.github/workflows/scraper.yml` | Cron cada 2 dies + execució manual amb mode test |

## Seguretat i límits
- Les claus viuen només als Secrets de GitHub; mai al codi.
- Màxim 40 actes nous per run (`MAX_ACTES_PER_RUN`), amb 1,5 s de pausa entre peticions: scraping responsable.
- Si el cercador canvia d'estructura, el sistema passa al pla B (portada) i marca la font com a **Revisar estructura** a Notion perquè ho vegis.
- Cap acció irreversible: el scraper només CREA entrades noves i actualitza el log de la font. Mai no modifica ni esborra entrades revisades.

## Fonts cobertes
El scraper llegeix la base 🌐 FONTS WEB de Notion i processa TOTES les fonts amb Activa = Sí:
- **Agenda Ajuntament Tarragona**: mòdul dedicat (cercador oficial amb rang de dates avui → +30 dies i dedup per UID únic).
- **La resta (Tarragona Turisme, MNAT, MAMT, CaixaForum, Diputació · Cultura, Port Tarragona)**: mòdul genèric — llegeix la pàgina d'agenda, Gemini n'extreu la llista d'activitats dins de la finestra de 30 dies (regla "no inventar"), i es dedueix per URL i per títol+data.
- Per afegir una font nova NO cal tocar codi: crea-la a 🌐 FONTS WEB amb la seva URL i Activa = Sí.
- Si una web carrega el contingut amb JavaScript (pot passar amb CaixaForum) i retorna poc text, la font es marca com a **Revisar estructura** a Notion en lloc de crear entrades poc fiables.
- Nota: si el nom d'una font no existeix com a opció del camp "Font" de l'INBOX, Notion crea l'opció automàticament al primer run.

## Què queda fora d'aquesta versió (a propòsit)
- Captures d'imatges (això ja funciona directament al xat de Claude).
- CRM, formularis i missatges de confirmació (fases 3-5 del pla).
- Webs 100% JavaScript: si alguna font queda sistemàticament en "Revisar estructura", li farem un tractament específic.
